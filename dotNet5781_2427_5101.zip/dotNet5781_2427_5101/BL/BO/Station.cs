﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BO
{
    public class Station
    {
        public int Code { get; set; }
        public string Name { get; set; }
        public double Longtitude { get; set; }
        public double Latitude { get; set; }
        //public bool InService;
    }
}
