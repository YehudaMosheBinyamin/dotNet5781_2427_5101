﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotNet5781_00_3289_5101
{
    partial class Program
    {
        static partial void Welcome5101()
        {
            Console.WriteLine("I an also here");
            
        }
    }
}
